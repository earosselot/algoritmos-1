#include "../definiciones.h"

void ordenarTh(eph_h &th);

void ordenarTi(eph_i &ti, const eph_h &th);
